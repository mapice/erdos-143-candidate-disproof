# Lean supplement for the Erdős Problem 143 manuscript

Mattia Apicella. Prepared October 23, 2026.

This archive accompanies “A rational counterexample to the reciprocal-logarithmic
assertion in Erdős problem 143”. It contains the unchanged October 2 proof
sources, pinned dependency versions, the revised mathematical manuscript, the original
manuscript for provenance, and local verification records. It does not contain
downloaded dependencies, compiler binaries, account information or Git history.

## Reproduce

Use Lean 4.24.0 and mathlib revision
`f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. All transitive revisions are in
`lake-manifest.json`. From this archive's `erdos143-lean/` directory:

```sh
bash scripts/bootstrap.sh
bash scripts/verify.sh

bash scripts/verify-manuscript.sh
```

The bootstrap requires network access, Bash, Python 3, Git, curl, tar and zstd,
with several GB of disk space. On Linux x86_64 it downloads the pinned official
Lean release when Lake is not already available, and verifies its SHA-256.
Both verification scripts make that local toolchain available internally;
changes inside `bash scripts/bootstrap.sh` do not persist in the calling shell.
On other systems first install Lean
through [elan](https://github.com/leanprover/elan); `lean-toolchain` selects the
required version. Dependency caches may be used; this procedure does not
rebuild the Lean compiler and all of mathlib from source.

`scripts/verify.sh` checks integrity, rejects proof placeholders and added
axioms, builds with warnings as errors, audits all 245 proved project
declarations, and compiles the expanded rational and real statements.
`ManuscriptAudit.lean` adds explicit checks of the strong statement and the
same recursive witness and prefix weight bound. Its additional theorem
`Erdos143.manuscript_full_statement` combines these conclusions in one
existential statement, including an explicit `A.Infinite` field. It is checked
separately from the 245 frozen project declarations. The only axiom dependencies
of the final theorems are `propext`, `Classical.choice` and `Quot.sound`.

## Read the proof

- `paper/erdos143-candidate.pdf` and `.tex`: current 16-page manuscript.
- `Erdos143/Definitions.lean`: exact definitions and rational conclusions.
- `Erdos143/PeriodicSelection.lean`: proved periodic primitive-selection lemma.
- `Erdos143/Main.lean`: recursion, nested union, strong rational conclusion.
- `Erdos143/RealConclusion.lean`: explicit real-domain conclusion and real nonsummability.
- `docs/`: detailed analytic and construction explanations.
- `submission/blms-2026-10-23/CORRISPONDENZA-TEX-LEAN.md`: additional statement correspondence in Italian.
- `verification/2026-10-23/`: fresh local verification logs and metadata.
- `verification/2026-10-02/`: historical local verification records.
- `paper/original-2026-10-02/`: unchanged historical manuscript source and PDF.

The current editorial revision changes exposition and presentation; it does
not alter the frozen Lean sources. Original proof and artifact digests remain
checked by `scripts/check_integrity.py`. `SUPPLEMENT-SHA256SUMS` additionally
identifies every supplied file outside that digest list itself.

To typeset the manuscript, with a local TeX installation:

```sh
bash scripts/build-paper.sh
```

This does not run Lean. New verification and typesetting logs go to `logs/`
and `paper/build/`; historical evidence is not overwritten.

## Scope and use

The construction addresses the reciprocal-logarithmic convergence question.
It is consistent with the distinct logarithmic-density theorem of
Koukoulopoulos–Lamzouri–Lichtman. The paper's AI Declaration records assistance
with exploration, proof development, formalization and exposition.
The local checks are not independent expert review, journal acceptance,
an exhaustive priority assessment or a prize award.

No open-source licence has been selected for the author's project; it is
supplied for evaluation with the manuscript. Lean and mathlib retain their
own licences. The repository address is
https://github.com/mapice/erdos-143-candidate-disproof; reproduction from this
archive does not require access to that repository.
