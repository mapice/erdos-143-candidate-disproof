#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
  printf 'This bootstrap is for Linux x86_64. Install Lean 4.24.0 for your platform, then use lake.\n' >&2
  exit 1
fi
LEAN_VERSION=4.24.0
LEAN_SHA256=b14f5e5159219dd1a1956c3b806813319f5e94ccd5bdfd56f54520609a5bb5ec
mkdir -p tooling logs
if [[ ! -x "tooling/lean-${LEAN_VERSION}-linux/bin/lean" ]]; then
  archive="tooling/lean-${LEAN_VERSION}-linux.tar.zst"
  curl --fail --location --retry 3 \
    "https://github.com/leanprover/lean4/releases/download/v${LEAN_VERSION}/lean-${LEAN_VERSION}-linux.tar.zst" \
    -o "$archive"
  printf '%s  %s\n' "$LEAN_SHA256" "$archive" | sha256sum --check -
  tar --zstd -xf "$archive" -C tooling
fi
export PATH="$PWD/tooling/lean-${LEAN_VERSION}-linux/bin:$PATH"
export XDG_CACHE_HOME="$PWD/tooling/cache"
export MATHLIB_NO_CACHE_ON_UPDATE=1
lean --version | tee logs/toolchain.log
lake update 2>&1 | tee logs/bootstrap-update.log
mapfile -t imports < <(grep -h '^import Mathlib\.' Erdos143/*.lean | awk '{print $2}' | sort -u)
lake exe cache get "${imports[@]}" 2>&1 | tee logs/bootstrap-cache.log
printf '\nToolchain and pinned dependencies are ready. Run bash scripts/verify.sh.\n'
