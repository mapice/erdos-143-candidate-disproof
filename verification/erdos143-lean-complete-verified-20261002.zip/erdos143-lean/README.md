# Erdős 143: formalizzazione Lean della candidata

I teoremi chiusi `Erdos143.mainConclusion_proved` e
`Erdos143.strongConclusion_proved` dimostrano gli enunciati completi, senza
ipotesi analitiche o costruttive aggiunte. `Erdos143.realConclusion_proved`
trasferisce esplicitamente il risultato a un sottoinsieme dei reali e dimostra
anche la non sommabilità reale del peso. La verifica del kernel non sostituisce
la revisione indipendente della corrispondenza con il problema matematico.

## Enunciato esatto

Esiste un insieme numerabile `A : Set ℚ`, contenuto in `[2,∞)`, tale che per
ogni coppia **ordinata** di elementi distinti e ogni `k : ℕ` con `1 ≤ k`:

    1 ≤ |k*a-b|.

La somma nonnegativa di `1/(a*log(a))` è infinita. È espressa come una somma
in `ENNReal` uguale a `⊤`, non come il valore convenzionale di una `tsum`
reale non sommabile. Il teorema sul dominio reale dimostra separatamente
`¬ Summable`, usando la nonnegatività dei termini. L'immersione `ℚ → ℝ` è
iniettiva e viene usata tramite un'equivalenza esplicita dei due sottotipi.

La conclusione più forte aggiunge la finitezza locale e, per ogni punto `a`,
l'esistenza di un intero naturale `m≥2` tale che

    0 < a-m ≤ 1/(2*m^12).

`StatementAudit.lean` controlla anche gli enunciati esistenziali completamente
espansi, senza affidarsi solo ai nomi delle definizioni.

## Percorso della prova

1. Prodotti di Eulero pesati da Ω, stime uniformi dei caratteri non principali,
   polo principale, identità integrali e controllo del secondo momento logaritmico
2. Minorante di Abel `1/(4L)` per ogni classe di residui, estrazione di un livello
   primitivo e selezione finita di peso `>1/6` a distanza arbitraria
3. Conteggio esatto delle esclusioni periodiche e passaggio a un periodo comune,
   senza supporre indipendenza dei vincoli
4. Scelta nell'ordine corretto di primo privato, etichette primitive e primo
   ausiliario; verifica simultanea degli invarianti e delle due direzioni
   delle disuguaglianze di separazione
5. Esistenza di ogni round, con guadagno almeno `1/576`
6. Ricorsione sui round, unione annidata, divergenza del peso e passaggio ai reali

La prova analitica e la mappa dei teoremi sono in `Abel-periodic-proof.md`.
Le semplificazioni sufficienti rispetto alla prima candidata e la corrispondenza
costruttiva sono in `Construction-correspondence.md`. In particolare, non si
pretende di aver provato il più forte liminf di ogni singolo livello Ω.

## Ambiente riproducibile

- Lean 4.24.0, commit `797c613eb9b6d4ec95db23e3e00af9ac6657f24b`
- mathlib, commit `f897ebcf72cd16f89ab4577d0c826cd14afaafc7` (v4.24.0)
- Dipendenze transitive fissate in `lake-manifest.json`
- Verifica locale; nessuna pubblicazione del repository remoto

Su Linux x86_64:

    bash scripts/bootstrap.sh
    bash scripts/verify.sh

Il bootstrap usa il rilascio ufficiale fissato di Lean, verificato con SHA256,
e la cache ufficiale di mathlib. Richiede rete, `curl`, `git`, `tar`, `zstd` e
`python3`. Con Lean 4.24.0 già installato, si possono usare direttamente `lake`
e i comandi della verifica. Il progetto tratta i warning come errori.

I log completi del build, dell'audit e degli enunciati sono in `logs/`.
La cartella `.lake`, il compilatore e le cache non sono necessari nel pacchetto
dei sorgenti: il bootstrap li ricostruisce dalle revisioni fissate.

## Assiomi fondazionali e assenza di lacune

Non sono presenti `sorry`, `admit`, assiomi personalizzati, `native_decide` o
sostituzioni non sicure delle dimostrazioni. `AxiomAudit.lean` esegue realmente
`#print axioms` su ogni lemma e teorema del progetto. Le dipendenze logiche dei
tre teoremi conclusivi sono esattamente:

    [propext, Classical.choice, Quot.sound]

Sono le fondazioni standard di Lean/mathlib: estensionalità proposizionale,
scelta classica e correttezza dei quozienti. Non sono nuove assunzioni
aritmetiche o analitiche. Il controllo automatico rifiuta qualsiasi assioma
fuori da questa lista, un audit incompleto o l'assenza dei teoremi conclusivi.
